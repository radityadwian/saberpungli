<?php
include "../Operational/web_config_vars.php";
		if ($_POST['act']=="add"){
    $sql_add="INSERT INTO contact(email,subject,message) VALUES ("
    ."'".$_POST['email']."','".$_POST['subject']."','".$_POST['message']."'
    ) ";
    @mysql_query($sql_add);
  
  if ($sql_add)
  echo'<script>alert("Message Sent");window.location.href="../index.php#contact"</script>';

}
?>